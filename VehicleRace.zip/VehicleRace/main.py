from flask import Flask, render_template
from flask import request
from flask_paginate import Pagination, get_page_parameter
import mysql.connector
mydb=mysql.connector.connect(host='localhost',user='root',password='Python1234@',port='3306',database='vehiclerace',auth_plugin='mysql_native_password')
mycursor=mydb.cursor()
mycursor.execute("CREATE TABLE IF NOT EXISTS event (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, ename VARCHAR(255), starttimestamp DATE, endtimestamp DATE, locationid INT(10))")
mycursor.execute("CREATE TABLE IF NOT EXISTS vehicle (id INT  NOT NULL AUTO_INCREMENT PRIMARY KEY, vehiclenumber VARCHAR(255),vname VARCHAR(255), eventid INT(10))")
mycursor.execute("CREATE TABLE IF NOT EXISTS location (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, lname VARCHAR(255), address VARCHAR(255))")


app = Flask(__name__)

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/event" , methods=['GET', 'POST'])
def event():
    if request.method == 'POST' and 'newevent' in request.form:
        mycursor.execute('SELECT id,lname FROM location')
        locationlist = mycursor.fetchall()
        return render_template('newevent.html', locationlist=locationlist)
    elif request.method == 'POST' and 'newdone' in request.form:
        n1 = request.form['ename']
        s1 = request.form['starttimestamp']
        e1 = request.form['endtimestamp']
        l1 = request.form['locationid']
        sql = "INSERT INTO event (ename,starttimestamp,endtimestamp,locationid) VALUES (%s, %s, %s, %s)"
        val = (n1, s1, e1, l1)
        mycursor.execute(sql, val)
        mydb.commit()
        mycursor.execute('SELECT id,lname FROM location')
        locationlist = mycursor.fetchall()
        return render_template('newevent.html', locationlist=locationlist)
    elif request.method == 'POST' and 'updateevent' in request.form:

        tname = 'event'
        page = 1
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]


        mycursor.execute('SELECT * FROM location')
        locationlist = mycursor.fetchall()
        return render_template('eventupdate.html', eventlist=rlist, locationlist=locationlist, arr=arr)
    elif request.method == 'POST' and 'updatedone' in request.form:
        id1 = request.form['updatedone']
        n1 = request.form['ename'+id1]
        s1 = request.form['starttimestamp'+id1]
        e1 = request.form['endtimestamp'+id1]
        l1 = request.form['locationid'+id1]
        mycursor.execute("UPDATE event SET ename = %s, starttimestamp = %s, endtimestamp = %s, locationid = %s WHERE id = %s",
                       (n1, s1, e1, l1, id1))
        mydb.commit()

        tname = 'event'
        page = 1
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        mycursor.execute('SELECT * FROM location')
        locationlist = mycursor.fetchall()
        return render_template('eventupdate.html', eventlist=rlist, locationlist=locationlist, arr=arr)
    elif request.method == 'POST' and 'deleteevent' in request.form:

        tname = 'event'
        page = 1
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        mycursor.execute('SELECT * FROM location')
        locationlist = mycursor.fetchall()

        return render_template('eventdelete.html', eventlist=rlist, locationlist=locationlist, arr=arr)
    elif request.method == 'POST' and 'deletedone' in request.form:
        id1 = request.form['deletedone']
        t1='event'
        mycursor.execute("DELETE FROM %s WHERE id = %s" % (t1, id1))
        mydb.commit()
        z1 = '0'
        mycursor.execute("UPDATE vehicle SET eventid = %s WHERE eventid = %s", (z1, id1))
        mydb.commit()

        tname = 'event'
        page = 1
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        mycursor.execute('SELECT * FROM location')
        locationlist = mycursor.fetchall()

        return render_template('eventdelete.html', eventlist=rlist, locationlist=locationlist, arr=arr)
    elif request.method == 'POST' and 'eventlist' in request.form:

        tname = 'event'
        page = 1
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        mycursor.execute('SELECT * FROM location')
        locationlist = mycursor.fetchall()

        return render_template('eventlist.html', eventlist=rlist, locationlist=locationlist, arr=arr)
    elif request.method == 'POST' and 'peventlist' in request.form:

        ntemp = request.form['tempname']
        tname = request.form['tblname']
        pn = request.form['ppage']
        page = int(pn)
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        mycursor.execute('SELECT * FROM location')
        locationlist = mycursor.fetchall()

        return render_template(ntemp+'.html', eventlist=rlist, locationlist=locationlist, arr=arr)
    elif request.method == 'POST' and 'neventlist' in request.form:

        ntemp = request.form['tempname']
        tname = request.form['tblname']
        pn = request.form['npage']
        page = int(pn)
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        mycursor.execute('SELECT * FROM location')
        locationlist = mycursor.fetchall()

        return render_template(ntemp + '.html', eventlist=rlist, locationlist=locationlist, arr=arr)
    else: return render_template('event.html')

@app.route("/vehicle", methods=['GET', 'POST'])
def vehicle():
    if request.method == 'POST' and 'newvehicle' in request.form:
        mycursor.execute('SELECT id,ename FROM event')
        eventlist = mycursor.fetchall()
        return render_template('newvehicle.html', eventlist=eventlist)
    elif request.method == 'POST' and 'vnewdone' in request.form:
        n1 = request.form['vnumber']
        n2 = request.form['vname']
        e1 = request.form['eventid']
        sql = "INSERT INTO vehicle (vehiclenumber,vname,eventid) VALUES (%s, %s, %s)"
        val = (n1, n2, e1)
        mycursor.execute(sql, val)
        mydb.commit()
        mycursor.execute('SELECT id,ename FROM event')
        eventlist = mycursor.fetchall()
        return render_template('newvehicle.html', eventlist=eventlist)
    elif request.method == 'POST' and 'updatevehicle' in request.form:

        tname = 'vehicle'
        page = 1
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        mycursor.execute('SELECT * FROM event')
        eventlist = mycursor.fetchall()

        return render_template('vehicleupdate.html', vehiclelist=rlist, eventlist=eventlist, arr=arr)
    elif request.method == 'POST' and 'vupdatedone' in request.form:
        id1 = request.form['vupdatedone']
        n1 = request.form['vnumber' + id1]
        n2 = request.form['vname' + id1]
        e1 = request.form['eventid' + id1]
        mycursor.execute(
            "UPDATE vehicle SET vehiclenumber = %s,vname = %s, eventid = %s WHERE id = %s",
            (n1, n2, e1, id1))
        mydb.commit()

        tname = 'vehicle'
        page = 1
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        mycursor.execute('SELECT * FROM event')
        eventlist = mycursor.fetchall()

        return render_template('vehicleupdate.html', vehiclelist=rlist, eventlist=eventlist, arr=arr)
    elif request.method == 'POST' and 'deletevehicle' in request.form:

        tname = 'vehicle'
        page = 1
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        mycursor.execute('SELECT * FROM event')
        eventlist = mycursor.fetchall()

        return render_template('vehicledelete.html', vehiclelist=rlist, eventlist=eventlist, arr=arr)
    elif request.method == 'POST' and 'vdeletedone' in request.form:
        id1 = request.form['vdeletedone']
        t1 = 'vehicle'
        mycursor.execute("DELETE FROM %s WHERE id = %s" % (t1, id1))
        mydb.commit()

        tname = 'vehicle'
        page = 1
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        mycursor.execute('SELECT * FROM event')
        eventlist = mycursor.fetchall()

        return render_template('vehicledelete.html', vehiclelist=rlist, eventlist=eventlist, arr=arr)
    elif request.method == 'POST' and 'vehiclelist' in request.form:

        tname = 'vehicle'
        page = 1
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        mycursor.execute('SELECT * FROM event')
        eventlist = mycursor.fetchall()

        return render_template('vehiclelist.html', vehiclelist=rlist, eventlist=eventlist, arr=arr)
    elif request.method == 'POST' and 'pvehiclelist' in request.form:

        ntemp = request.form['tempname']
        tname = request.form['tblname']
        pn = request.form['ppage']
        page = int(pn)
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        mycursor.execute('SELECT * FROM event')
        eventlist = mycursor.fetchall()

        return render_template(ntemp+'.html', vehiclelist=rlist, eventlist=eventlist, arr=arr)
    elif request.method == 'POST' and 'nvehiclelist' in request.form:

        ntemp = request.form['tempname']
        tname = request.form['tblname']
        pn = request.form['npage']
        page = int(pn)
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        mycursor.execute('SELECT * FROM event')
        eventlist = mycursor.fetchall()

        return render_template(ntemp + '.html', vehiclelist=rlist, eventlist=eventlist, arr=arr)


    else:
        return render_template('vehicle.html')

ROWS_PER_PAGE = 5
@app.route("/location", methods=['GET', 'POST'])
def location():
    if request.method == 'POST' and 'newlocation' in request.form:
        return render_template('newlocation.html')
    elif request.method == 'POST' and 'lnewdone' in request.form:
        n1 = request.form['lname']
        n2 = request.form['laddress']
        sql = "INSERT INTO location (lname,address) VALUES (%s, %s)"
        val = (n1, n2)
        mycursor.execute(sql, val)
        mydb.commit()
        return render_template('newlocation.html')
    elif request.method == 'POST' and 'updatelocation' in request.form:

        tname = 'location'
        page = 1
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        return render_template('locationupdate.html', locationlist=rlist, arr=arr)
    elif request.method == 'POST' and 'lupdatedone' in request.form:
        id1 = request.form['lupdatedone']
        n1 = request.form['lname' + id1]
        n2 = request.form['laddress' + id1]
        mycursor.execute(
            "UPDATE location SET lname = %s,address = %s WHERE id = %s",
            (n1, n2, id1))
        mydb.commit()

        tname = 'location'
        page = 1
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        return render_template('locationupdate.html', locationlist=rlist, arr=arr)
    elif request.method == 'POST' and 'deletelocation' in request.form:

        tname = 'location'
        page = 1
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        return render_template('locationdelete.html', locationlist=rlist, arr=arr)
    elif request.method == 'POST' and 'ldeletedone' in request.form:
        id1 = request.form['ldeletedone']
        t1 = 'location'
        mycursor.execute("DELETE FROM %s WHERE id = %s" % (t1, id1))
        mydb.commit()
        z1 = '0'
        mycursor.execute("UPDATE event SET locationid = %s WHERE locationid = %s",(z1, id1))
        mydb.commit()

        tname = 'location'
        page = 1
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        return render_template('locationdelete.html', locationlist=rlist, arr=arr)
    elif request.method == 'POST' and 'listlocation' in request.form:

        tname = 'location'
        page = 1
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        return render_template('locationlist.html', locationlist=rlist, arr=arr)
    elif request.method == 'POST' and 'plistlocation' in request.form:

        ntemp = request.form['tempname']
        tname = request.form['tblname']
        pn = request.form['ppage']
        page = int(pn)
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        return render_template(ntemp+'.html', locationlist=rlist, arr=arr)
    elif request.method == 'POST' and 'nlistlocation' in request.form:

        ntemp = request.form['tempname']
        tname = request.form['tblname']
        pn = request.form['npage']
        page = int(pn)
        elem_to_display = 3
        offset = (page - 1) * elem_to_display
        mycursor.execute("SELECT  * FROM %s LIMIT %s OFFSET %s" % (tname, elem_to_display, offset))
        rlist = mycursor.fetchall()
        mycursor.execute("SELECT  * FROM %s" % (tname))
        trlist = mycursor.fetchall()
        tot = len(trlist)
        arr = [page, elem_to_display, tot]

        return render_template(ntemp+'.html', locationlist=rlist, arr=arr)
    else:
        return render_template('location.html')


if __name__ == "__main__":
    app.run(debug=True)