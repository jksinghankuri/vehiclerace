#File for vehicles

class Vehicle:
  def __init__(self, vehiclenumber, name, eventid):
    self.vehiclenumber = vehiclenumber
    self.name = name
    self.eventid = eventid


V1 = Vehicle("John", 36)

sql = """INSERT INTO vehicle(vehiclenumber, name, eventid) VALUES (V1.vehiclenumber, V1.name, V1.eventid)"""

try:
   # Executing the SQL command
   mycursor.execute(sql)

   # Commit your changes in the database
   mydb.commit()

except:
   # Rolling back in case of error
   mydb.rollback()
