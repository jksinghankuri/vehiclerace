#File for location

class Location:
  def __init__(self, name, address):
    self.name = name
    self.address = address


L1 = location("John", 36)

sql = """INSERT INTO location(name, address) VALUES (L1.name, L1.address)"""

try:
   # Executing the SQL command
   mycursor.execute(sql)

   # Commit your changes in the database
   mydb.commit()

except:
   # Rolling back in case of error
   mydb.rollback()
