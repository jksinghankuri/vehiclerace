import mysql.connector
mydb=mysql.connector.connect(host='localhost',user='root',password='Python1234@',port='3306',database='vehiclerace')
if mydb.is_connected():	print("done")
mycursor=mydb.cursor()
mycursor.execute("CREATE TABLE IF NOT EXISTS event (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), starttimestamp TIMESTAMP, endtimestamp TIMESTAMP, locationid INT(10))")
mycursor.execute("CREATE TABLE IF NOT EXISTS vehicle (id INT AUTO_INCREMENT PRIMARY KEY, vehiclenumber VARCHAR(255),name VARCHAR(255), eventid INT(10))")
mycursor.execute("CREATE TABLE IF NOT EXISTS location (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), address VARCHAR(255))")

sql = """INSERT INTO event(name, starttimestamp, endtimestamp, locationid) VALUES ('Mac', 'Mohan', 20, 2)"""

try:
   # Executing the SQL command
   mycursor.execute(sql)

   # Commit your changes in the database
   mydb.commit()

except:
   # Rolling back in case of error
   mydb.rollback()

# Closing the connection
mydb.close()