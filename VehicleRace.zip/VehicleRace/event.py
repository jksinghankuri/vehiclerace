#File for events

class Event:
  def __init__(self, name, starttimestamp, endtimestamp, locationid):
    self.name = name
    self.starttimestamp = starttimestamp
    self.endtimestamp = endtimestamp
    self.locationid = locationid


E1 = Event("John", 36)

sql = """INSERT INTO event(name, starttimestamp, endtimestamp, locationid) VALUES (E1.name, E1.starttimestamp, E1.endtimestamp, E1.locationid)"""

try:
   # Executing the SQL command
   mycursor.execute(sql)

   # Commit your changes in the database
   mydb.commit()

except:
   # Rolling back in case of error
   mydb.rollback()

